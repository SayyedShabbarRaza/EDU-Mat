import 'package:flutter/material.dart';

class AppTextfieldControllers {
  // Admin Log in Data
  static final TextEditingController adminSignInEmail = TextEditingController();
  static final TextEditingController adminSignInPassword = TextEditingController();

  // ======================== Add School Data ==================================
  static final TextEditingController adminschoolName = TextEditingController();
  static final TextEditingController adminSchoolLink =
      TextEditingController();

       // ======================== Add University Data ==================================
  static final TextEditingController adminUniName = TextEditingController();
  static final TextEditingController adminUniLink = TextEditingController();

         // ======================== Add College Data ==================================
  static final TextEditingController adminCollegeName = TextEditingController();
  static final TextEditingController adminCollegeLink = TextEditingController();

           // ======================== Add Old Papaer Data ==================================
  static final TextEditingController adminOldPapereName = TextEditingController();
  static final TextEditingController adminOldpaperLink = TextEditingController();
}
