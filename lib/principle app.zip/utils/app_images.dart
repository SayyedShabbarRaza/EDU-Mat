class AppImages {
  static const applogo = "assets/app_images/logo.png";
  static const intro1 = "assets/app_images/intro1.png";
  static const intro2 = "assets/app_images/intro2.png";
  static const intro3 = "assets/app_images/intro3.png";
  static const paper = "assets/app_images/paper.png";
  static const profile = "assets/app_images/profile.png";
  static const school = "assets/app_images/school.png";
  static const student = "assets/app_images/student.png";
  static const subcriber = "assets/app_images/subcriber.png";
  static const teacher = "assets/app_images/teacher.png";
  static const university = "assets/app_images/university.png";
  static const dashboardIcon = "assets/app_images/dashboardIcon.png";
  static const oldquestionIcon = "assets/app_images/oldquestionIcon.png";
  static const profileIcon = "assets/app_images/profileIcon.png";
  static const schoolIcondashboard =
      "assets/app_images/profileIcondashboard.png";
  static const bursoriesIcon = "assets/app_images/bursoriesIcion.png";
  static const profileIconbottom = "assets/app_images/profileIconbottom.png";
  static const newsFeed = "assets/app_images/newsFeed.png";
  static const uniimg = 'assets/app_images/download 1.png';
  static const unilogo = 'assets/app_images/images 1 (1).png';
  static const learnerimg = 'assets/app_images/10769187_4529178.png';
  static const principleimg = 'assets/app_images/58597033_9462016.png';
  static const staffimg = 'assets/app_images/5984908_57274 1.png';
  static const quiz = 'assets/app_images/OBJECTS.png';
  static const oldpaper = 'assets/app_images/4320553_2286301 1.png';
  static const svgrepo = 'assets/app_images/copy_svgrepo.com.png';
  static const editsvgrepo = 'assets/app_images/edit-3_svgrepo.com.png';
  static const students = 'assets/app_images/students.png';
  static const announcement = 'assets/app_images/announcement.png';
  static const teacher2 = 'assets/app_images/teachera.png';
  static const emptyImage = 'assets/app_images/empty_image.png';
  static const avatar = 'assets/app_images/avatar.png';
}
